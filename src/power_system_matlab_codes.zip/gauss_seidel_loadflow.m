function [V,iter,busData] = gauss_seidel_loadflow(Ybus,busData,tol,maxIter,alpha)
% GAUSS_SEIDEL_LOADFLOW  General Gauss-Seidel load flow.
%
% BUS DATA COLUMNS:
% [type Vm(pu) Va(deg) Pg Qg Pl Ql Qmin Qmax]
% type: 1 = Slack, 2 = PV, 3 = PQ.
% All powers are pu. PV generator Q limits are enforced; a violating PV
% bus is converted to PQ at the violated limit.
%
% alpha is the acceleration factor (1.0 = ordinary Gauss-Seidel).
% Typical optional value: 1.0 to 1.6. Start with 1.0 for reliability.

    if nargin<3 || isempty(tol), tol=1e-6; end
    if nargin<4 || isempty(maxIter), maxIter=1000; end
    if nargin<5 || isempty(alpha), alpha=1.0; end

    n=size(Ybus,1);
    if size(Ybus,2)~=n || size(busData,1)~=n || size(busData,2)<9
        error('Ybus must be n x n and busData must be n x 9.');
    end
    type=busData(:,1); Vm=busData(:,2); delta=deg2rad(busData(:,3));
    Pg=busData(:,4); Qg=busData(:,5); Pl=busData(:,6); Ql=busData(:,7);
    Qmin=busData(:,8); Qmax=busData(:,9);
    P=Pg-Pl; Q=Qg-Ql;
    slack=find(type==1);
    if numel(slack)~=1, error('Exactly one slack bus is required.'); end
    V=Vm.*exp(1i*delta);
    Vslack=V(slack);

    converged=false;
    for iter=1:maxIter
        Vold=V;
        for i=1:n
            if type(i)==1, continue; end
            sumYV=0;
            for k=1:n
                if k~=i, sumYV=sumYV+Ybus(i,k)*V(k); end
            end

            if type(i)==2
                % Estimate Q at PV bus using latest available voltages.
                I=Ybus(i,:)*V;
                Qcalc=imag(V(i)*conj(I));
                Qgen=Qcalc+Ql(i);
                if Qgen<Qmin(i)
                    type(i)=3; Q(i)=Qmin(i)-Ql(i);
                elseif Qgen>Qmax(i)
                    type(i)=3; Q(i)=Qmax(i)-Ql(i);
                else
                    Q(i)=-Qcalc; % temporary sign convention handled below
                    % Standard update uses specified net Q injection.
                    Qnet=Qcalc;
                    Vtemp=((P(i)-1i*Qnet)/conj(V(i))-sumYV)/Ybus(i,i);
                    Vnew=Vtemp*Vm(i)/abs(Vtemp);
                    V(i)=V(i)+alpha*(Vnew-V(i));
                    continue;
                end
            end

            Vnew=((P(i)-1i*Q(i))/conj(V(i))-sumYV)/Ybus(i,i);
            V(i)=V(i)+alpha*(Vnew-V(i));
        end
        V(slack)=Vslack;
        if max(abs(V-Vold))<tol
            converged=true; break;
        end
    end

    Vm=abs(V); delta=angle(V);
    I=Ybus*V; S=V.*conj(I);
    Pcalc=real(S); Qcalc=imag(S);
    busData(:,1)=type; busData(:,2)=Vm; busData(:,3)=rad2deg(delta);
    busData(:,4)=Pcalc+Pl; busData(:,5)=Qcalc+Ql;

    if ~converged
        warning('Gauss-Seidel did not converge in %d iterations.',maxIter);
    end
    fprintf('\nGauss-Seidel Load Flow\nIterations: %d\n',iter);
    fprintf(' Bus       |V| (pu)    Angle (deg)       Pgen (pu)       Qgen (pu)\n');
    for k=1:n
        fprintf('%4d      %10.5f    %10.5f      %10.5f      %10.5f\n', ...
            k,Vm(k),rad2deg(delta(k)),busData(k,4),busData(k,5));
    end
end
