function Ybus = ybus_formation(nbus, lineData, busShunt)
% YBUS_FORMATION  Form the bus-admittance matrix using branch stamping.
%
% INPUTS
%   nbus     : number of buses
%   lineData : one row per line/transformer:
%              [from to R X B tap]
%              B   = total line-charging susceptance in pu (use 0 if ignored)
%              tap = real off-nominal tap ratio (use 1 for a normal line)
%   busShunt : nbus x 1 vector of shunt admittances in pu (optional).
%              Use 0 when there are no bus shunts.
%
% OUTPUT
%   Ybus : nbus x nbus bus-admittance matrix in pu.
%
% Example:
%   lineData = [1 2 0.02 0.06 0.03 1;
%               1 3 0.08 0.24 0.025 1;
%               2 3 0.06 0.18 0.02 1];
%   Y = ybus_formation(3,lineData,zeros(3,1));

    if nargin < 3 || isempty(busShunt)
        busShunt = zeros(nbus,1);
    end

    if size(lineData,2) < 4 || size(lineData,2) > 6
        error('lineData must have 4, 5, or 6 columns: [from to R X (B) (tap)].');
    end
    if numel(busShunt) ~= nbus
        error('busShunt must contain one value per bus.');
    end

    Ybus = complex(zeros(nbus));
    for k = 1:size(lineData,1)
        p = lineData(k,1);
        q = lineData(k,2);
        R = lineData(k,3);
        X = lineData(k,4);

        if size(lineData,2) >= 5, B = lineData(k,5); else, B = 0; end
        if size(lineData,2) >= 6, tap = lineData(k,6); else, tap = 1; end

        if p < 1 || p > nbus || q < 1 || q > nbus || p == q
            error('Invalid bus number in lineData row %d.',k);
        end
        if tap == 0, error('Tap ratio cannot be zero.'); end
        z = R + 1i*X;
        if abs(z) == 0, error('Line impedance cannot be zero.'); end

        y = 1/z;
        % Real off-nominal tap at the from-bus; pi-model line charging.
        Ybus(p,p) = Ybus(p,p) + (y + 1i*B/2)/(tap^2);
        Ybus(q,q) = Ybus(q,q) + y + 1i*B/2;
        Ybus(p,q) = Ybus(p,q) - y/tap;
        Ybus(q,p) = Ybus(q,p) - y/tap;
    end

    Ybus = Ybus + diag(busShunt(:));
end
