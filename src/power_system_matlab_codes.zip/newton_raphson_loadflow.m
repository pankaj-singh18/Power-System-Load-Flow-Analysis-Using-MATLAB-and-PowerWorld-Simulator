function [V, delta, iter, busData] = newton_raphson_loadflow(Ybus,busData,tol,maxIter)
% NEWTON_RAPHSON_LOADFLOW  General Newton-Raphson load flow in polar form.
%
% BUS DATA COLUMNS:
% [type Vm(deg? no: pu) Va(deg) Pg Qg Pl Ql Qmin Qmax]
% type: 1 = Slack, 2 = PV, 3 = PQ
% Pg,Qg,Pl,Ql are pu injections/loads on a common system base.
% Qmin,Qmax are generator reactive limits in pu.
% For buses without a generator, set Pg=Qg=Qmin=Qmax=0 and use type 3.
% Slack-bus Pg and Qg are calculated. PV-bus Qg is calculated.
%
% Ybus must be in pu. Angles in busData are entered in degrees.
% PV buses are converted to PQ when their Q limits are violated.
%
% Example:
%   [V,delta,it,busData] = newton_raphson_loadflow(Y,busData,1e-6,50);

    if nargin < 3 || isempty(tol), tol = 1e-6; end
    if nargin < 4 || isempty(maxIter), maxIter = 50; end
    n = size(Ybus,1);
    if size(Ybus,2) ~= n || size(busData,1) ~= n || size(busData,2) < 9
        error('Ybus must be n x n and busData must be n x 9.');
    end

    type = busData(:,1);
    Vm = busData(:,2);
    delta = deg2rad(busData(:,3));
    Pg = busData(:,4); Qg = busData(:,5);
    Pl = busData(:,6); Ql = busData(:,7);
    Qmin = busData(:,8); Qmax = busData(:,9);
    Pspec = Pg-Pl;
    Qspec = Qg-Ql;

    slack = find(type==1);
    if numel(slack) ~= 1, error('Exactly one slack bus is required.'); end

    converged = false;
    for iter = 1:maxIter
        [Pcalc,Qcalc] = calcPQ(Ybus,Vm,delta);

        % Enforce PV generator reactive limits and convert violating buses to PQ.
        for k = find(type==2).'
            Qgen = Qcalc(k) + Ql(k);
            if Qgen < Qmin(k)
                type(k)=3; Qspec(k)=Qmin(k)-Ql(k);
                busData(k,5)=Qmin(k);
            elseif Qgen > Qmax(k)
                type(k)=3; Qspec(k)=Qmax(k)-Ql(k);
                busData(k,5)=Qmax(k);
            end
        end

        pv = find(type==2);
        pq = find(type==3);
        angBus = find(type~=1);
        mismatch = [Pspec(angBus)-Pcalc(angBus); Qspec(pq)-Qcalc(pq)];
        if norm(mismatch,inf) < tol
            converged = true;
            break;
        end

        % Numerical Jacobian: robust for arbitrary network size and bus mix.
        x = [delta(angBus); Vm(pq)];
        J = zeros(numel(mismatch),numel(x));
        h = 1e-6;
        for c = 1:numel(x)
            xp = x; xp(c)=xp(c)+h;
            dp=delta; vp=Vm;
            dp(angBus)=xp(1:numel(angBus));
            if ~isempty(pq), vp(pq)=xp(numel(angBus)+1:end); end
            [Pp,Qp]=calcPQ(Ybus,vp,dp);
            mp=[Pspec(angBus)-Pp(angBus); Qspec(pq)-Qp(pq)];
            J(:,c)=(mp-mismatch)/h;
        end
        dx = -J \ mismatch;
        delta(angBus)=delta(angBus)+dx(1:numel(angBus));
        if ~isempty(pq)
            Vm(pq)=Vm(pq)+dx(numel(angBus)+1:end);
        end
        if any(Vm <= 0), error('A bus voltage magnitude became non-positive. Check data/convergence.'); end
    end

    [Pcalc,Qcalc]=calcPQ(Ybus,Vm,delta);
    busData(:,1)=type;
    busData(:,2)=Vm;
    busData(:,3)=rad2deg(delta);
    busData(:,4)=Pcalc+Pl;
    busData(:,5)=Qcalc+Ql;

    V = Vm .* exp(1i*delta);
    if ~converged
        warning('Newton-Raphson did not converge in %d iterations. Final mismatch = %.3e pu.', ...
                maxIter,norm([Pspec(find(type~=1))-Pcalc(find(type~=1)); ...
                Qspec(find(type==3))-Qcalc(find(type==3))],inf));
    end
    fprintf('\nNewton-Raphson Load Flow\nIterations: %d\n',iter);
    fprintf(' Bus       |V| (pu)    Angle (deg)       Pgen (pu)       Qgen (pu)\n');
    for k=1:n
        fprintf('%4d      %10.5f    %10.5f      %10.5f      %10.5f\n', ...
            k,Vm(k),rad2deg(delta(k)),busData(k,4),busData(k,5));
    end
end

function [P,Q] = calcPQ(Y,V,ang)
    n=numel(V); P=zeros(n,1); Q=zeros(n,1);
    for i=1:n
        for k=1:n
            G=real(Y(i,k)); B=imag(Y(i,k));
            th=ang(i)-ang(k);
            P(i)=P(i)+V(i)*V(k)*(G*cos(th)+B*sin(th));
            Q(i)=Q(i)+V(i)*V(k)*(G*sin(th)-B*cos(th));
        end
    end
end
