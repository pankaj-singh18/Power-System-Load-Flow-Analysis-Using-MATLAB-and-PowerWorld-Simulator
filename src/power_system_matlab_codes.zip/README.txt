POWER SYSTEM ANALYSIS - GENERAL MATLAB FUNCTIONS

FILES
1. ybus_formation.m
2. newton_raphson_loadflow.m
3. gauss_seidel_loadflow.m
4. fast_decoupled_loadflow.m
5. symmetrical_faults.m
6. unsymmetrical_faults.m

GENERAL CONVENTIONS
- All quantities are per unit unless stated otherwise.
- Bus numbering starts at 1 and must be consecutive.
- Bus type: 1 = Slack, 2 = PV, 3 = PQ.
- Load-flow busData columns:
  [type Vm(pu) Va(deg) Pg Qg Pl Ql Qmin Qmax]
- Generation and load powers are positive magnitudes in pu.
- Qmin/Qmax are generator reactive-power limits in pu.
- For a bus without a generator, use type=3 and set Pg=Qg=Qmin=Qmax=0.
- Exactly one slack bus is required.
- Ybus lineData columns:
  [from to R X B tap]
  B is total line-charging susceptance; tap=1 for a normal line.
  If line charging is ignored, enter B=0. If tap is omitted, it defaults to 1.
- busShunt is an optional vector of bus shunt admittances in pu.

BASIC WORKFLOW
1. Create Ybus:
   Y = ybus_formation(nbus,lineData,zeros(nbus,1));
2. Run one load-flow method:
   [V,delta,it,busData] = newton_raphson_loadflow(Y,busData,1e-6,50);
   OR gauss_seidel_loadflow(Y,busData,1e-6,1000,1.0);
   OR fast_decoupled_loadflow(Y,busData,1e-6,100);
3. For a 3-phase fault:
   result = symmetrical_faults(Y,faultBus,[],Zf);
4. For an unsymmetrical fault:
   Z1=Y1\\eye(nbus); Z2=Y2\\eye(nbus); Z0=Y0\\eye(nbus);
   result=unsymmetrical_faults(Z1,Z2,Z0,faultBus,[],'SLG',0);

IMPORTANT
- Use the same system base and bus ordering in all matrices.
- For unsymmetrical faults, construct separate positive-, negative-, and
  zero-sequence networks. The zero-sequence network must reflect transformer
  winding connections and grounding; it is not generally identical to Ybus.
- For a prefault load-flow solution, pass V = Vm.*exp(1i*deg2rad(Va)) as Vpref.
- The functions print results and also return outputs.
- Validate numerical results against your class convention, especially the
  fault-impedance definition for line-to-line faults and transformer tap models.
