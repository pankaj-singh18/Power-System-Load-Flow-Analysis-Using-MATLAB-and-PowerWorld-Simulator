function result = unsymmetrical_faults(Zbus1,Zbus2,Zbus0,faultBus,Vpref,faultType,Zf)
% UNSYMMETRICAL_FAULTS  SLG, LL, and DLG faults using sequence Z-bus matrices.
%
% INPUTS:
%   Zbus1,Zbus2,Zbus0 : positive-, negative-, and zero-sequence Zbus matrices
%   faultBus          : faulted bus number
%   Vpref             : prefault positive-sequence voltage vector (pu);
%                       use [] for 1 angle 0 pu at all buses
%   faultType         : 'SLG', 'LL', or 'DLG'
%   Zf                : fault impedance in pu (use 0 for solid fault)
%
% Assumed fault connections:
%   SLG: phase-a-to-ground
%   LL : phase-b-to-phase-c
%   DLG: phases b and c to ground
%
% OUTPUT fields include sequence currents at fault, phase currents, and
% sequence/phase voltages at the faulted bus.
%
% Note: All sequence networks must use the same pu base and bus ordering.

    n=size(Zbus1,1);
    if nargin<5 || isempty(Vpref), Vpref=ones(n,1); end
    if nargin<6 || isempty(faultType), faultType='SLG'; end
    if nargin<7 || isempty(Zf), Zf=0; end
    if any(size(Zbus1)~=[n n]) || any(size(Zbus2)~=[n n]) || any(size(Zbus0)~=[n n])
        error('All three sequence Zbus matrices must be square and the same size.');
    end
    if faultBus<1 || faultBus>n || numel(Vpref)~=n
        error('Check faultBus and Vpref dimensions.');
    end

    Z1=Zbus1(faultBus,faultBus);
    Z2=Zbus2(faultBus,faultBus);
    Z0=Zbus0(faultBus,faultBus);
    E=Vpref(faultBus);
    I0=0; I1=0; I2=0;

    switch upper(strtrim(faultType))
        case {'SLG','LG','SINGLE LINE TO GROUND'}
            I1=E/(Z1+Z2+Z0+3*Zf);
            I2=I1; I0=I1;
        case {'LL','LINE TO LINE'}
            I1=E/(Z1+Z2+Zf);
            I2=-I1; I0=0;
        case {'DLG','LLG','DOUBLE LINE TO GROUND','LINE LINE TO GROUND'}
            den=Z2+Z0+3*Zf;
            I1=E/(Z1+(Z2*(Z0+3*Zf))/den);
            I2=-I1*(Z0+3*Zf)/den;
            I0=-I1*Z2/den;
        otherwise
            error('faultType must be SLG, LL, or DLG.');
    end

    a=exp(1i*2*pi/3);
    A=[1 1 1; 1 a^2 a; 1 a a^2];
    Iseq=[I0;I1;I2];
    Iabc=A*Iseq;

    V1=E-Z1*I1;
    V2=-Z2*I2;
    V0=-Z0*I0;
    Vseq=[V0;V1;V2];
    Vabc=A*Vseq;

    result.I0=I0; result.I1=I1; result.I2=I2;
    result.Iabc=Iabc;
    result.V0=V0; result.V1=V1; result.V2=V2;
    result.Vabc=Vabc;
    result.Z1=Z1; result.Z2=Z2; result.Z0=Z0;

    fprintf('\n%s FAULT AT BUS %d\n',upper(faultType),faultBus);
    fprintf('Sequence currents (pu):\n');
    fprintf('I0 = %.6f %+.6fj\n',real(I0),imag(I0));
    fprintf('I1 = %.6f %+.6fj\n',real(I1),imag(I1));
    fprintf('I2 = %.6f %+.6fj\n',real(I2),imag(I2));
    fprintf('\nPhase currents (pu):\n');
    fprintf('Ia = %.6f %+.6fj\n',real(Iabc(1)),imag(Iabc(1)));
    fprintf('Ib = %.6f %+.6fj\n',real(Iabc(2)),imag(Iabc(2)));
    fprintf('Ic = %.6f %+.6fj\n',real(Iabc(3)),imag(Iabc(3)));
    fprintf('\nPhase voltages at faulted bus (pu):\n');
    fprintf('Va = %.6f %+.6fj\n',real(Vabc(1)),imag(Vabc(1)));
    fprintf('Vb = %.6f %+.6fj\n',real(Vabc(2)),imag(Vabc(2)));
    fprintf('Vc = %.6f %+.6fj\n',real(Vabc(3)),imag(Vabc(3)));
end
