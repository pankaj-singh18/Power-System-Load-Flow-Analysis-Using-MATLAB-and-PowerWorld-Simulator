function [V,iter,busData] = fast_decoupled_loadflow(Ybus,busData,tol,maxIter)
% FAST_DECOUPLED_LOADFLOW  Fast-Decoupled Load Flow (XB-style approximation).
%
% BUS DATA COLUMNS:
% [type Vm(pu) Va(deg) Pg Qg Pl Ql Qmin Qmax]
% type: 1 = Slack, 2 = PV, 3 = PQ. Powers in pu; angles in degrees.
% PV buses are converted to PQ if calculated generator Q violates limits.
%
% Uses B' = -imag(Ybus) reduced to non-slack buses and
% B'' = -imag(Ybus) reduced to PQ buses. This is a common simplified
% fast-decoupled formulation. For networks with unusual transformer taps,
% shunts, or high R/X ratio, check against NR.

    if nargin<3 || isempty(tol), tol=1e-6; end
    if nargin<4 || isempty(maxIter), maxIter=100; end
    n=size(Ybus,1);
    if size(Ybus,2)~=n || size(busData,1)~=n || size(busData,2)<9
        error('Ybus must be n x n and busData must be n x 9.');
    end

    type=busData(:,1); Vm=busData(:,2); delta=deg2rad(busData(:,3));
    Pg=busData(:,4); Qg=busData(:,5); Pl=busData(:,6); Ql=busData(:,7);
    Qmin=busData(:,8); Qmax=busData(:,9);
    Pspec=Pg-Pl; Qspec=Qg-Ql;
    slack=find(type==1);
    if numel(slack)~=1, error('Exactly one slack bus is required.'); end

    nonSlack=find(type~=1);
    Bp=-imag(Ybus(nonSlack,nonSlack));
    converged=false;

    for iter=1:maxIter
        [Pcalc,Qcalc]=calcPQfd(Ybus,Vm,delta);
        % Reactive limit enforcement for PV buses.
        for k=find(type==2).'
            Qgen=Qcalc(k)+Ql(k);
            if Qgen<Qmin(k)
                type(k)=3; Qspec(k)=Qmin(k)-Ql(k);
            elseif Qgen>Qmax(k)
                type(k)=3; Qspec(k)=Qmax(k)-Ql(k);
            end
        end
        pq=find(type==3);
        nonSlack=find(type~=1);
        dP=Pspec(nonSlack)-Pcalc(nonSlack);
        if ~isempty(dP)
            rhs=dP./Vm(nonSlack);
            dDelta=Bp\rhs;
            delta(nonSlack)=delta(nonSlack)+dDelta;
        end

        [Pcalc,Qcalc]=calcPQfd(Ybus,Vm,delta);
        pq=find(type==3);
        if ~isempty(pq)
            Bpp=-imag(Ybus(pq,pq));
            dQ=Qspec(pq)-Qcalc(pq);
            rhs=dQ./Vm(pq);
            dV=Bpp\rhs;
            Vm(pq)=Vm(pq)+dV;
        end

        [Pcalc,Qcalc]=calcPQfd(Ybus,Vm,delta);
        mismatch=[Pspec(find(type~=1))-Pcalc(find(type~=1)); ...
                  Qspec(find(type==3))-Qcalc(find(type==3))];
        if norm(mismatch,inf)<tol
            converged=true; break;
        end
    end

    [Pcalc,Qcalc]=calcPQfd(Ybus,Vm,delta);
    busData(:,1)=type; busData(:,2)=Vm; busData(:,3)=rad2deg(delta);
    busData(:,4)=Pcalc+Pl; busData(:,5)=Qcalc+Ql;
    V=Vm.*exp(1i*delta);

    if ~converged
        warning('Fast-Decoupled Load Flow did not converge in %d iterations.',maxIter);
    end
    fprintf('\nFast-Decoupled Load Flow\nIterations: %d\n',iter);
    fprintf(' Bus       |V| (pu)    Angle (deg)       Pgen (pu)       Qgen (pu)\n');
    for k=1:n
        fprintf('%4d      %10.5f    %10.5f      %10.5f      %10.5f\n', ...
            k,Vm(k),rad2deg(delta(k)),busData(k,4),busData(k,5));
    end
end

function [P,Q]=calcPQfd(Y,V,ang)
    n=numel(V); P=zeros(n,1); Q=zeros(n,1);
    for i=1:n
        for k=1:n
            th=ang(i)-ang(k);
            P(i)=P(i)+V(i)*V(k)*(real(Y(i,k))*cos(th)+imag(Y(i,k))*sin(th));
            Q(i)=Q(i)+V(i)*V(k)*(real(Y(i,k))*sin(th)-imag(Y(i,k))*cos(th));
        end
    end
end
