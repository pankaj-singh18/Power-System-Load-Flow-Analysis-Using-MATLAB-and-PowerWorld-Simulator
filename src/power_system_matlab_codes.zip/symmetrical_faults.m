function result = symmetrical_faults(Ybus,faultBus,Vpref,Zf)
% SYMMETRICAL_FAULTS  Three-phase bolted/impedance fault using Ybus.
%
% INPUTS:
%   Ybus     : positive-sequence bus admittance matrix (pu)
%   faultBus : faulted bus number
%   Vpref    : prefault positive-sequence bus voltage vector (pu).
%              Use [] to assume 1 angle 0 pu at every bus.
%   Zf       : fault impedance in pu; use 0 for a solid fault.
%
% OUTPUT fields:
%   Zbus, Zth, Ifault, Vduring
%
% Fault current is positive-sequence current. For a balanced 3-phase fault,
% phase-current magnitudes are equal and separated by 120 degrees.

    n=size(Ybus,1);
    if nargin<3 || isempty(Vpref), Vpref=ones(n,1); end
    if nargin<4 || isempty(Zf), Zf=0; end
    if faultBus<1 || faultBus>n, error('Invalid fault bus.'); end
    if numel(Vpref)~=n, error('Vpref must have one value per bus.'); end

    Zbus=Ybus\eye(n);
    Zth=Zbus(faultBus,faultBus);
    Ifault=Vpref(faultBus)/(Zth+Zf);
    Vduring=Vpref-Zbus(:,faultBus)*Ifault;

    result.Zbus=Zbus;
    result.Zth=Zth;
    result.Ifault=Ifault;
    result.Vduring=Vduring;

    fprintf('\nTHREE-PHASE SYMMETRICAL FAULT AT BUS %d\n',faultBus);
    fprintf('Thevenin impedance = %.5f %+.5fj pu\n',real(Zth),imag(Zth));
    fprintf('Fault current       = %.5f %+.5fj pu\n',real(Ifault),imag(Ifault));
    fprintf('Fault current       = %.5f angle %.3f deg pu\n',abs(Ifault),rad2deg(angle(Ifault)));
    fprintf('\nBus      |V during fault| (pu)     Angle (deg)\n');
    for k=1:n
        fprintf('%3d       %12.6f        %10.4f\n',k,abs(Vduring(k)),rad2deg(angle(Vduring(k))));
    end
end
